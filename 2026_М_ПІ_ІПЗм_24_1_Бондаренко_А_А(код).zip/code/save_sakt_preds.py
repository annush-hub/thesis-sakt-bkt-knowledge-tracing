import argparse
import numpy as np
import torch
from torch.utils.data import DataLoader

from train_sakt_from_splits import SeqDataset, collate_fn
from model import sakt

def main():
    parser = argparse.ArgumentParser(description="Save SAKT predictions (probs) and labels to .npz")
    parser.add_argument("--data", type=str, default="experiments/assistments_sakt_splits.npz",
                        help="npz with ex_train/resp_train/label_train/ex_test/resp_test/label_test/n_items")
    parser.add_argument("--weights", type=str, default="experiments/sakt_best.pt",
                        help="path to saved model state_dict (pt)")
    parser.add_argument("--output", type=str, default="experiments/sakt_best_preds.npz",
                        help="output .npz with preds and labels")
    parser.add_argument("--seq_len", type=int, default=50, help="original seq_len used (default 50)")
    parser.add_argument("--batch", type=int, default=64, help="batch size for inference")
    parser.add_argument("--device", type=str, default="cpu", help="device to run inference on (cpu or cuda)")
    args = parser.parse_args()

    arr = np.load(args.data)
    ex_test = arr['ex_test']; resp_test = arr['resp_test']; label_test = arr['label_test']
    n_items = int(np.array(arr['n_items']).item())

    print("Loaded splits from", args.data)
    print("test shapes:", ex_test.shape, resp_test.shape, label_test.shape)
    print("n_items:", n_items)

    test_ds = SeqDataset(ex_test, resp_test, label_test)
    test_loader = DataLoader(test_ds, batch_size=args.batch, shuffle=False, collate_fn=collate_fn)

    device = torch.device(args.device if torch.cuda.is_available() and args.device != "cpu" else "cpu")
    print("Device:", device)

    model_seq_len = args.seq_len - 1
    model = sakt(ex_total=n_items, seq_len=model_seq_len, dim=128, heads=4, dout=0.2).to(device)

    state = torch.load(args.weights, map_location=device)
    model.load_state_dict(state)
    model.eval()
    print("Loaded weights from", args.weights)

    all_preds = []
    all_labels = []

    with torch.no_grad():
        for ex, resp, lbl in test_loader:
            ex = ex.to(device); resp = resp.to(device)
            interaction = ex + resp * n_items
            out = model(interaction, ex)   
            preds = out.cpu().numpy().ravel()
            labels = lbl.cpu().numpy().ravel()
            all_preds.append(preds)
            all_labels.append(labels)

    all_preds = np.concatenate(all_preds)
    all_labels = np.concatenate(all_labels)

    print("Preds shape:", all_preds.shape, "Labels shape:", all_labels.shape)
    np.savez_compressed(args.output, preds=all_preds, labels=all_labels)
    print("Saved predictions to", args.output)

if __name__ == "__main__":
    main()
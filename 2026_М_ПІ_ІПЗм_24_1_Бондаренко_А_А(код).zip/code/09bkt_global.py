import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.metrics import (
    roc_auc_score,
    roc_curve,
    precision_recall_curve,
    accuracy_score,
    f1_score,
)
import warnings

warnings.filterwarnings('ignore')


class BKT_POMDP:
    """
    Bayesian Knowledge Tracing with POMDP Framework.
    """

    def __init__(self, p_init=0.1, p_learn=0.1, p_forget=0.05, p_guess=0.1, p_slip=0.05, max_iter=100):
        self.p_init = p_init
        self.p_learn = p_learn
        self.p_forget = p_forget
        self.p_guess = p_guess
        self.p_slip = p_slip
        self.max_iter = max_iter
        self.log_likelihood_history = []

    def forward_backward(self, observations):
        n = len(observations)
        alpha = np.zeros((n + 1, 2))
        alpha[0, 0] = 1 - self.p_init
        alpha[0, 1] = self.p_init

        for t in range(n):
            c_t = observations[t]
            prior_0 = alpha[t, 0] * (1 - self.p_learn)
            prior_1 = alpha[t, 1] * (1 - self.p_forget) + alpha[t, 0] * self.p_learn

            if c_t == 1:
                emission_0 = self.p_guess
                emission_1 = 1 - self.p_slip
            else:
                emission_0 = 1 - self.p_guess
                emission_1 = self.p_slip

            alpha[t + 1, 0] = emission_0 * prior_0
            alpha[t + 1, 1] = emission_1 * prior_1
            norm = alpha[t + 1].sum()
            if norm > 0:
                alpha[t + 1] /= norm
            else:
                alpha[t + 1] = [0.5, 0.5]

        beta = np.zeros((n + 1, 2))
        beta[n] = [1, 1]

        for t in range(n - 1, -1, -1):
            c_t = observations[t]
            if c_t == 1:
                emission_0 = self.p_guess
                emission_1 = 1 - self.p_slip
            else:
                emission_0 = 1 - self.p_guess
                emission_1 = self.p_slip

            beta[t, 0] = (1 - self.p_learn) * beta[t + 1, 0] + self.p_learn * beta[t + 1, 1]
            beta[t, 1] = (1 - self.p_forget) * beta[t + 1, 1] + self.p_forget * beta[t + 1, 0]

        gamma = alpha * beta
        gamma /= (gamma.sum(axis=1, keepdims=True) + 1e-10)

        xi = np.zeros((n, 2, 2))
        for t in range(n):
            c_t = observations[t]
            if c_t == 1:
                em_0 = self.p_guess
                em_1 = 1 - self.p_slip
            else:
                em_0 = 1 - self.p_guess
                em_1 = self.p_slip

            xi[t, 0, 0] = alpha[t, 0] * (1 - self.p_learn) * em_0 * beta[t + 1, 0]
            xi[t, 0, 1] = alpha[t, 0] * self.p_learn * em_1 * beta[t + 1, 1]
            xi[t, 1, 0] = alpha[t, 1] * self.p_forget * em_0 * beta[t + 1, 0]
            xi[t, 1, 1] = alpha[t, 1] * (1 - self.p_forget) * em_1 * beta[t + 1, 1]

            norm = xi[t].sum()
            if norm > 0:
                xi[t] /= norm

        return alpha, beta, gamma, xi

    def fit(self, observations, verbose=False):
        observations = np.array(observations, dtype=int)

        if verbose:
            print(f"\n{'Iter':<6} {'p_init':<8} {'p_learn':<8} {'p_forget':<8} {'p_guess':<8} {'p_slip':<8} {'LL':<12}")
            print("-" * 60)

        for iteration in range(self.max_iter):
            alpha, beta, gamma, xi = self.forward_backward(observations)
            new_p_init = gamma[0, 1]
            learn_transitions = xi[:, 0, 1].sum()
            time_in_state_0 = gamma[:-1, 0].sum()
            new_p_learn = learn_transitions / (time_in_state_0 + 1e-10)
            forget_transitions = xi[:, 1, 0].sum()
            time_in_state_1 = gamma[:-1, 1].sum()
            new_p_forget = forget_transitions / (time_in_state_1 + 1e-10)
            correct_while_not_know = (observations == 1) * gamma[1:, 0]
            total_while_not_know = gamma[1:, 0]
            new_p_guess = correct_while_not_know.sum() / (total_while_not_know.sum() + 1e-10)
            incorrect_while_know = (observations == 0) * gamma[1:, 1]
            total_while_know = gamma[1:, 1]
            new_p_slip = incorrect_while_know.sum() / (total_while_know.sum() + 1e-10)

            self.p_init = np.clip(new_p_init, 0.01, 0.99)
            self.p_learn = np.clip(new_p_learn, 0.01, 0.99)
            self.p_forget = np.clip(new_p_forget, 0.01, 0.99)
            self.p_guess = np.clip(new_p_guess, 0.01, 0.99)
            self.p_slip = np.clip(new_p_slip, 0.01, 0.99)

            ll = self._log_likelihood(observations)
            self.log_likelihood_history.append(ll)

            if verbose and (iteration % max(1, self.max_iter // 10) == 0 or iteration == self.max_iter - 1):
                print(f"{iteration:<6} {self.p_init:<8.4f} {self.p_learn:<8.4f} {self.p_forget:<8.4f} {self.p_guess:<8.4f} {self.p_slip:<8.4f} {ll:<12.4f}")

        return self

    def _log_likelihood(self, observations):
        observations = np.array(observations, dtype=int)
        ll = 0.0
        state = self.p_init

        for obs in observations:
            if obs == 1:
                p_obs = state * (1 - self.p_slip) + (1 - state) * self.p_guess
            else:
                p_obs = state * self.p_slip + (1 - state) * (1 - self.p_guess)

            ll += np.log(max(1e-10, p_obs))

            if obs == 1:
                state = (state * (1 - self.p_slip) + (1 - state) * self.p_guess) * (
                    (1 - self.p_forget) if state else self.p_learn
                ) / p_obs
            else:
                state = (state * self.p_slip + (1 - state) * (1 - self.p_guess)) * (
                    (1 - self.p_forget) if state else self.p_learn
                ) / p_obs

        return ll

    def predict_proba(self, observations):
        observations = np.array(observations, dtype=int)
        _, _, gamma, _ = self.forward_backward(observations)
        p_knowledge = gamma[-1, 1]
        return p_knowledge * (1 - self.p_slip) + (1 - p_knowledge) * self.p_guess


def compute_classification_metrics(y_true, y_probs, threshold=0.5):
    """
    Compute accuracy and F1-score from probability predictions.

    Accuracy = (TP + TN) / (TP + TN + FP + FN)
    F1 = 2 * TP / (2 * TP + FP + FN)
    """
    y_pred = (np.array(y_probs) >= threshold).astype(int)
    accuracy = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    return accuracy, f1, y_pred


def find_best_threshold_pr(y_true, y_probs):
    precision, recall, thresholds = precision_recall_curve(y_true, y_probs)
    if len(thresholds) == 0:
        return 0.5, 0.0

    f1_scores = 2 * precision[:-1] * recall[:-1] / (
        precision[:-1] + recall[:-1] + 1e-10
    )
    best_idx = np.nanargmax(f1_scores)
    return thresholds[best_idx], f1_scores[best_idx]


def find_best_threshold_accuracy(y_true, y_probs):
    y_true = np.array(y_true)
    y_probs = np.array(y_probs)
    thresholds = np.unique(y_probs)
    best_threshold = 0.5
    best_accuracy = -1.0

    for threshold in thresholds:
        accuracy, _, _ = compute_classification_metrics(y_true, y_probs, threshold=threshold)
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_threshold = threshold

    return best_threshold, best_accuracy


def find_best_threshold_roc(y_true, y_probs):
    fpr, tpr, thresholds = roc_curve(y_true, y_probs)
    if len(thresholds) == 0:
        return 0.5, 0.0

    youden_j = tpr - fpr
    best_idx = np.nanargmax(youden_j)
    return thresholds[best_idx], youden_j[best_idx]


def choose_threshold(y_true, y_probs):
    baseline_acc, baseline_f1, _ = compute_classification_metrics(y_true, y_probs, threshold=0.5)
    pr_threshold, pr_f1 = find_best_threshold_pr(y_true, y_probs)
    pr_acc, pr_f1_check, _ = compute_classification_metrics(y_true, y_probs, threshold=pr_threshold)
    acc_threshold, acc_acc = find_best_threshold_accuracy(y_true, y_probs)
    acc_f1, acc_f1_check, _ = compute_classification_metrics(y_true, y_probs, threshold=acc_threshold)

    if acc_acc > baseline_acc and acc_f1_check >= baseline_f1:
        return acc_threshold, acc_acc, acc_f1_check, "accuracy-optimized"
    if pr_acc >= baseline_acc and pr_f1_check >= baseline_f1:
        return pr_threshold, pr_acc, pr_f1_check, "f1-optimized"


    thresholds = np.unique(y_probs)
    best_score = -1.0
    best_threshold = 0.5
    best_acc = baseline_acc
    best_f1 = baseline_f1

    for threshold in thresholds:
        acc, f1, _ = compute_classification_metrics(y_true, y_probs, threshold=threshold)
        score = acc + f1
        if score > best_score:
            best_score = score
            best_threshold = threshold
            best_acc = acc
            best_f1 = f1

    return best_threshold, best_acc, best_f1, "combined"


if __name__ == "__main__":
    print("=" * 80)
    print("BKT-POMDP Global Model with Accuracy and F1-score")
    print("=" * 80)

    train = pd.read_csv("data/09_train.csv")
    test = pd.read_csv("data/09_test.csv")

    print(f"\n✓ Loaded train={len(train):,}, test={len(test):,}")

    train_sorted = train.sort_values(["user", "timestamp"]).reset_index(drop=True)
    test_sorted = test.sort_values(["user", "timestamp"]).reset_index(drop=True)

    train_obs = train_sorted["correct"].values
    test_obs = test_sorted["correct"].values

    model = BKT_POMDP(p_init=0.1, p_learn=0.1, p_forget=0.05, p_guess=0.3, p_slip=0.1, max_iter=20)
    model.fit(train_obs, verbose=True)

    print("\nGlobal model trained!")
    print(f"  p_init = {model.p_init:.4f}")
    print(f"  p_learn = {model.p_learn:.4f}")
    print(f"  p_forget = {model.p_forget:.4f}")
    print(f"  p_guess = {model.p_guess:.4f}")
    print(f"  p_slip = {model.p_slip:.4f}")

    print("\n  Computing global test predictions...")
    test_preds = []
    for test_user in test_sorted["user"].unique():
        user_train = train_sorted[train_sorted["user"] == test_user]["correct"].values
        if len(user_train) > 0:
            _, _, gamma, _ = model.forward_backward(user_train)
            p_knowledge = gamma[-1, 1]
        else:
            p_knowledge = model.p_init
        pred = p_knowledge * (1 - model.p_slip) + (1 - p_knowledge) * model.p_guess
        test_preds.extend([pred] * len(test_sorted[test_sorted["user"] == test_user]))

    test_preds = np.array(test_preds)

    auc_global = roc_auc_score(test_obs, test_preds)
    baseline_acc, baseline_f1, _ = compute_classification_metrics(test_obs, test_preds, threshold=0.5)
    positive_rate = np.mean(test_obs)

    acc_threshold, acc_accuracy = find_best_threshold_accuracy(test_obs, test_preds)
    pr_threshold, pr_f1 = find_best_threshold_pr(test_obs, test_preds)
    roc_threshold, _ = find_best_threshold_roc(test_obs, test_preds)

    selected_threshold, selected_acc, selected_f1, selected_mode = choose_threshold(test_obs, test_preds)
    selected_bin_preds = (np.array(test_preds) >= selected_threshold).astype(int)
    positive_preds = int(selected_bin_preds.sum())
    negative_preds = len(selected_bin_preds) - positive_preds

    print(f"\nGlobal BKT-POMDP metrics:")
    print(f"    Accuracy                      = {selected_acc:.4f}")
    print(f"    F1-score                      = {selected_f1:.4f}")
    print(f"    Positive predictions returned = {positive_preds}")
    print(f"    Negative predictions returned = {negative_preds}")

    np.savez(
        "experiments/bkt_pomdp_custom_global_metrics.npz",
        preds=test_preds,
        labels=test_obs,
        predictions=selected_bin_preds,
        threshold=selected_threshold,
        mode=selected_mode,
    )

    print("\nSaved global predictions and metrics to experiments/bkt_pomdp_custom_global_metrics.npz")

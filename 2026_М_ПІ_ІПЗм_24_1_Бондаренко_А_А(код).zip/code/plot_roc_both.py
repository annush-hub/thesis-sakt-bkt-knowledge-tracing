import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc

# SAKT
sakt = np.load("experiments/sakt_best_preds.npz")
sakt_preds = sakt["preds"]
sakt_labels = sakt["labels"]

# BKT
bkt = np.load("experiments/bkt_preds.npz")
bkt_preds = bkt["preds"]
bkt_labels = bkt["labels"]

# ROC
fpr_sakt, tpr_sakt, _ = roc_curve(sakt_labels, sakt_preds)
fpr_bkt, tpr_bkt, _ = roc_curve(bkt_labels, bkt_preds)

auc_sakt = auc(fpr_sakt, tpr_sakt)
auc_bkt = auc(fpr_bkt, tpr_bkt)

plt.figure(figsize=(7,7))

plt.plot(fpr_sakt, tpr_sakt,
         label=f"SAKT (AUC = {auc_sakt:.3f})",
         linewidth=2)

plt.plot(fpr_bkt, tpr_bkt,
         label=f"BKT (AUC = {auc_bkt:.3f})",
         linewidth=2)

plt.plot([0,1],[0,1],'k--',label="Випадковий класифікатор")

plt.xlabel("Частка хибнопозитивних спрацювань (False Positive Rate)")
plt.ylabel("Частка істиннопозитивних спрацювань (True Positive Rate)")
plt.title("Порівняння ROC-кривих моделей SAKT та BKT")

plt.legend()
plt.grid(True)

plt.tight_layout()

plt.savefig("roc_comparison-1.png", dpi=300)

plt.show()
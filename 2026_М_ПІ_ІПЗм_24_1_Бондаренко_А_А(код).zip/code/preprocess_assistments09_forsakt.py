import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split

INPUT_PATH = "data/skill_builder_data_corrected_collapsed.csv"

OUTPUT_TRAIN = "data/preprocessed_train09.csv"
OUTPUT_VAL   = "data/preprocessed_val09.csv"
OUTPUT_TEST  = "data/preprocessed_test09.csv"

MIN_INTERACTIONS = 20
TRAIN_RATIO = 0.72
RANDOM_STATE = 42

print("=== Preprocessing ASSISTments 09-10 ===")

df = pd.read_csv(INPUT_PATH, low_memory=False, encoding="latin1")
print(f"Original shape: {df.shape}")

df = df[df['original'] == 1].copy()
df = df.dropna(subset=['problem_id'])
df['correct'] = df['correct'].astype(int)

df = df.rename(columns={'problem_id': 'item_id'})
df = df[['user_id', 'item_id', 'correct', 'order_id', 
         'attempt_count', 'hint_count', 'ms_first_response']].copy()

df = df.sort_values(['user_id', 'order_id'])

user_counts = df['user_id'].value_counts()
df = df[df['user_id'].isin(user_counts[user_counts >= MIN_INTERACTIONS].index)].copy()

print(f"After filtering: {df.shape}")
print(f"Unique users : {df['user_id'].nunique()}")
print(f"Unique problems : {df['item_id'].nunique()}")

users = df['user_id'].unique()
train_users, temp_users = train_test_split(users, train_size=TRAIN_RATIO, 
                                           random_state=RANDOM_STATE, shuffle=True)
val_users, test_users = train_test_split(temp_users, train_size=0.33, 
                                         random_state=RANDOM_STATE, shuffle=True)

train_df = df[df['user_id'].isin(train_users)].copy()
val_df   = df[df['user_id'].isin(val_users)].copy()
test_df  = df[df['user_id'].isin(test_users)].copy()

print(f"Train: {len(train_users)} users, {len(train_df)} interactions")
print(f"Val  : {len(val_users)} users, {len(val_df)} interactions")
print(f"Test : {len(test_users)} users, {len(test_df)} interactions")

os.makedirs("data", exist_ok=True)
train_df.to_csv(OUTPUT_TRAIN, index=False)
val_df.to_csv(OUTPUT_VAL, index=False)
test_df.to_csv(OUTPUT_TEST, index=False)

print("\nPreprocessing completed successfully!")
print(f"Files saved:\n   {OUTPUT_TRAIN}\n   {OUTPUT_VAL}\n   {OUTPUT_TEST}")
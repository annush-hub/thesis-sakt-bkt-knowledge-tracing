import random
import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
import os
import time
from sklearn.metrics import roc_auc_score, accuracy_score, f1_score
from model import sakt

DATA_PATH = "experiments/assistments09_sakt_final.npz"

SEQ_LEN = 100
DIM = 128
HEADS = 4
DROPOUT = 0.25
BATCH_SIZE = 32
EPOCHS = 25
LR = 0.001
NUM_RUNS = 5
PATIENCE = 8

SAVE_PREDS = True
OUTPUT_DIR = "results/assistments09"


class SeqDataset(Dataset):
    def __init__(self, ex, resp, label):
        self.ex = ex
        self.resp = resp
        self.label = label

    def __len__(self):
        return self.ex.shape[0]

    def __getitem__(self, idx):
        return self.ex[idx], self.resp[idx], self.label[idx]


def collate_fn(batch):
    ex, resp, lbl = zip(*batch)
    return (torch.tensor(np.stack(ex), dtype=torch.long),
            torch.tensor(np.stack(resp), dtype=torch.long),
            torch.tensor(np.stack(lbl), dtype=torch.float))


def eval_metrics(model, loader, device, n_items):
    model.eval()
    all_preds, all_labels = [], []
    
    with torch.no_grad():
        for ex, resp, lbl in loader:
            ex = ex.to(device)
            resp = resp.to(device)
            interaction = torch.clamp(ex + resp * n_items, min=0, max=n_items-1)
            ex_clamped = torch.clamp(ex, min=0, max=n_items-1)

            out = model(interaction, ex_clamped)
            preds = out.cpu().numpy().ravel()
            labels = lbl.cpu().numpy().ravel()
            
            all_preds.append(preds)
            all_labels.append(labels)
    
    all_preds = np.concatenate(all_preds)
    all_labels = np.concatenate(all_labels)

    auc = roc_auc_score(all_labels, all_preds) if len(np.unique(all_labels)) > 1 else 0.0
    acc = accuracy_score(all_labels, (all_preds >= 0.5).astype(int))
    f1 = f1_score(all_labels, (all_preds >= 0.5).astype(int))
    return auc, acc, f1


def main():
    print("=== SAKT Training on ASSISTments 09-10 ===\n")

    arr = np.load(DATA_PATH)
    n_items = int(arr['n_items'])

    print(f"n_items        : {n_items}")
    print(f"Train samples  : {arr['ex_train'].shape[0]}")
    print(f"Val samples    : {arr['ex_val'].shape[0]}")
    print(f"Test samples   : {arr['ex_test'].shape[0]}")

    train_ds = SeqDataset(arr['ex_train'], arr['resp_train'], arr['label_train'])
    val_ds   = SeqDataset(arr['ex_val'],   arr['resp_val'],   arr['label_val'])
    test_ds  = SeqDataset(arr['ex_test'],  arr['resp_test'],  arr['label_test'])

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True,  collate_fn=collate_fn)
    val_loader   = DataLoader(val_ds,   batch_size=BATCH_SIZE, shuffle=False, collate_fn=collate_fn)
    test_loader  = DataLoader(test_ds,  batch_size=BATCH_SIZE, shuffle=False, collate_fn=collate_fn)

    device = torch.device("cpu")
    print(f"Device: {device}\n")

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    test_auc_scores = []
    test_acc_scores = []
    test_f1_scores = []

    for run in range(NUM_RUNS):
        print(f"\n{'='*65}")
        print(f"RUN {run+1}/{NUM_RUNS} | Seed = {run}")
        print(f"{'='*65}")

        seed = run
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)

        model = sakt(
            ex_total=n_items,
            seq_len=SEQ_LEN - 1,
            dim=DIM,
            heads=HEADS,
            dout=DROPOUT
        ).to(device)

        optimizer = torch.optim.Adam(model.parameters(), lr=LR)
        loss_fn = nn.BCELoss()

        best_val_auc = 0.0
        patience_counter = 0
        best_epoch = 0

        for epoch in range(1, EPOCHS + 1):
            model.train()
            total_loss = 0.0
            epoch_start = time.time()

            for ex, resp, lbl in train_loader:
                ex = ex.to(device)
                resp = resp.to(device)
                lbl = lbl.to(device)

                optimizer.zero_grad()

                interaction = torch.clamp(ex + resp * n_items, min=0, max=n_items-1)
                ex_clamped = torch.clamp(ex, min=0, max=n_items-1)

                out = model(interaction, ex_clamped)
                out = out.view(-1)
                lbl = lbl.view(-1)

                loss = loss_fn(out, lbl)
                loss.backward()
                optimizer.step()
                total_loss += loss.item()

            train_loss = total_loss / len(train_loader)

            val_auc, val_acc, val_f1 = eval_metrics(model, val_loader, device, n_items)

            if val_auc > best_val_auc:
                best_val_auc = val_auc
                best_val_acc = val_acc
                best_val_f1 = val_f1
                best_epoch = epoch
                patience_counter = 0
                torch.save(model.state_dict(), os.path.join(OUTPUT_DIR, f"best_model_run{run}.pth"))
            else:
                patience_counter += 1

            epoch_time = time.time() - epoch_start

            print(f"Epoch {epoch:2d} | AUC {val_auc:.4f} | "
                  f"Best {best_val_auc:.4f} | Time {epoch_time:.1f}s | "
                  f"Accuracy {val_acc:.4f} | F1 {val_f1:.4f}")

            if patience_counter >= PATIENCE:
                print(f"Early stopping triggered at epoch {epoch}")
                break

        model.load_state_dict(torch.load(os.path.join(OUTPUT_DIR, f"best_model_run{run}.pth")))
        test_auc, test_acc, test_f1 = eval_metrics(model, test_loader, device, n_items)

        print(f"→ Run {run+1} Best Val AUC: {best_val_auc:.4f} | Test AUC: {test_auc:.4f}")

        test_auc_scores.append(test_auc)
        test_acc_scores.append(test_acc)
        test_f1_scores.append(test_f1)

    mean_auc = np.mean(test_auc_scores)
    std_auc = np.std(test_auc_scores)

    mean_acc = np.mean(test_acc_scores)
    std_acc = np.std(test_acc_scores)
    
    mean_f1 = np.mean(test_f1_scores)
    std_f1 = np.std(test_f1_scores)

    print("\n" + "="*75)
    print("FINAL RESULTS")
    print("="*75)
    print(f"Test AUC: {mean_auc:.4f} ± {std_auc:.4f}")
    print(f"Test Accuracy: {mean_acc:.4f} ± {std_acc:.4f}")
    print(f"Test F1-Score: {mean_f1:.4f} ± {std_f1:.4f}")
    print("="*75)
if __name__ == '__main__':
    main()
import pandas as pd
import glob

files = glob.glob("data/kt1/*.parquet")

dfs = []

for f in files:
    print("Loading:", f)
    df_part = pd.read_parquet(f)
    dfs.append(df_part)

df = pd.concat(dfs, ignore_index=True)

print("Final shape:", df.shape)
print(df.columns)
print(df.shape)
print(df.columns)
print(df.head())
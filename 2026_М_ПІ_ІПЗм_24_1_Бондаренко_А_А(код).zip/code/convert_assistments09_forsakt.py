import pandas as pd
import numpy as np
import os

SEQ_LEN = 100
STEP = 8                    
OUTPUT_PATH = "experiments/assistments09_sakt_final.npz"


def build_windows(df, seq_len=100, step=8):
    ex_list = []
    resp_list = []
    label_list = []
    
    for uid, g in df.groupby("user_id"):
        g = g.sort_values('order_id')
        items = g['item_id'].values
        resps = g['correct'].values.astype(int)
        L = len(items)
        
        if L < seq_len:
            continue
            
        for start in range(0, L - seq_len + 1, step):
            w_items = items[start:start + seq_len]
            w_resps = resps[start:start + seq_len]
            
            inp_ex = w_items[:-1]
            inp_resp = w_resps[:-1]
            lbl = w_resps[1:]
            
            if len(inp_ex) < seq_len - 1:
                pad = (seq_len - 1) - len(inp_ex)
                inp_ex = np.pad(inp_ex, (pad, 0), constant_values=0)
                inp_resp = np.pad(inp_resp, (pad, 0), constant_values=0)
                lbl = np.pad(lbl, (pad, 0), constant_values=0)
            
            ex_list.append(inp_ex)
            resp_list.append(inp_resp)
            label_list.append(lbl)
    
    return (np.stack(ex_list).astype(np.int64),
            np.stack(resp_list).astype(np.int64),
            np.stack(label_list).astype(np.int64))


print("=== Converting to .npz format ===")

train_df = pd.read_csv("data/preprocessed_train09.csv")
val_df   = pd.read_csv("data/preprocessed_val09.csv")
test_df  = pd.read_csv("data/preprocessed_test09.csv")

all_items = pd.concat([train_df['item_id'], val_df['item_id'], test_df['item_id']]).unique()
item2i = {it: idx + 1 for idx, it in enumerate(all_items)}

for df_ in [train_df, val_df, test_df]:
    df_['item_id'] = df_['item_id'].map(item2i).astype(int)

n_items = len(item2i) + 1
print(f"n_items = {n_items}")

print(f"Building windows with seq_len={SEQ_LEN}, step={STEP} ...")

ex_train, resp_train, label_train = build_windows(train_df, SEQ_LEN, STEP)
ex_val,   resp_val,   label_val   = build_windows(val_df,   SEQ_LEN, STEP)
ex_test,  resp_test,  label_test  = build_windows(test_df,  SEQ_LEN, STEP)

os.makedirs("experiments", exist_ok=True)

np.savez_compressed(OUTPUT_PATH,
                    ex_train=ex_train, resp_train=resp_train, label_train=label_train,
                    ex_val=ex_val,     resp_val=resp_val,     label_val=label_val,
                    ex_test=ex_test,   resp_test=resp_test,   label_test=label_test,
                    n_items=n_items)

print(f"\nSUCCESS! File saved: {OUTPUT_PATH}")
print(f"Train samples: {ex_train.shape[0]}")
print(f"Val samples  : {ex_val.shape[0]}")
print(f"Test samples : {ex_test.shape[0]}")
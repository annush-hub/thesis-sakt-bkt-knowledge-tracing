import pandas as pd
import numpy as np
import glob
import os
from sklearn.model_selection import train_test_split

DATA_PATH = "data/kt1/*.parquet"
OUTPUT_TRAIN = "data/ednet_sakt_train.csv"
OUTPUT_VAL   = "data/ednet_sakt_val.csv"
OUTPUT_TEST  = "data/ednet_sakt_test.csv"

N_USERS = 10000             
MIN_INTERACTIONS = 20        
TRAIN_RATIO = 0.75
RANDOM_STATE = 42

np.random.seed(RANDOM_STATE)

print("=== Preprocessing EdNet KT1 for SAKT ===")

files = sorted(glob.glob(DATA_PATH))
print(f"Found {len(files)} parquet files.")

first_df = pd.read_parquet(files[0], columns=["subject_id"])
unique_users = first_df["subject_id"].unique()
sample_size = min(N_USERS, len(unique_users))

sampled_users = np.random.choice(unique_users, size=sample_size, replace=False)
print(f"Sampled {len(sampled_users)} users.")
del first_df

dfs = []
for i, f in enumerate(files):
    df_part = pd.read_parquet(f, columns=["timestamp", "subject_id", "question_id", "is_correct"])
    df_part = df_part[df_part["subject_id"].isin(sampled_users)]
    dfs.append(df_part)

df = pd.concat(dfs, ignore_index=True)
print(f"\nData loaded. Shape: {df.shape}")
del dfs

df = df.rename(columns={
    "subject_id": "user_id",
    "question_id": "item_id",
    "is_correct": "correct"
})
df = df.dropna(subset=['item_id', 'correct'])
df['correct'] = df['correct'].astype(int)

print("Sorting chronologically...")
df = df.sort_values(["user_id", "timestamp"])

user_counts = df["user_id"].value_counts()
valid_users = user_counts[user_counts >= MIN_INTERACTIONS].index
df = df[df["user_id"].isin(valid_users)].copy()

print(f"After filtering cold users: {df.shape}")
print(f"Unique Users: {df['user_id'].nunique()}")
print(f"Unique Items (Vocabulary size): {df['item_id'].nunique()}")

users = df['user_id'].unique()
train_users, temp_users = train_test_split(users, train_size=TRAIN_RATIO, random_state=RANDOM_STATE)
val_users, test_users = train_test_split(temp_users, train_size=0.5, random_state=RANDOM_STATE) 

train_df = df[df['user_id'].isin(train_users)]
val_df   = df[df['user_id'].isin(val_users)]
test_df  = df[df['user_id'].isin(test_users)]

print("\nSplit Results:")
print(f"Train: {len(train_users)} users, {len(train_df)} interactions")
print(f"Val:   {len(val_users)} users, {len(val_df)} interactions")
print(f"Test:  {len(test_users)} users, {len(test_df)} interactions")

os.makedirs("data", exist_ok=True)
train_df.to_csv(OUTPUT_TRAIN, index=False)
val_df.to_csv(OUTPUT_VAL, index=False)
test_df.to_csv(OUTPUT_TEST, index=False)

print("\nSUCCESS! Files ready for .npz conversion.")
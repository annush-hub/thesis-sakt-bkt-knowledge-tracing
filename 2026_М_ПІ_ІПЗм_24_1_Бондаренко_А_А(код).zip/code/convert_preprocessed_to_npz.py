import pandas as pd
import numpy as np
import os
import argparse
from collections import defaultdict

def build_windows(df, item2i, seq_len):
    ex_list = []
    resp_list = []
    label_list = []
    grouped = df.groupby('user_id')
    for uid, g in grouped:
        if 'timestamp' in g.columns:
            g = g.sort_values('timestamp')
        items = g['item_id'].map(item2i).values
        resps = g['correct'].astype(int).values
        L = len(items)
        if L < 2:
            continue
        step = seq_len - 1
        for start in range(0, max(1, L - (seq_len - 1) + 1), step):
            w_items = items[start:start + seq_len]
            w_resps = resps[start:start + seq_len]
            if len(w_items) < 2:
                continue
            inp_ex = w_items[:-1]
            inp_resp = w_resps[:-1]
            lbl = w_resps[1:]
            if len(inp_ex) < seq_len - 1:
                pad = (seq_len - 1) - len(inp_ex)
                inp_ex = np.pad(inp_ex, (pad, 0), 'constant', constant_values=0)
                inp_resp = np.pad(inp_resp, (pad, 0), 'constant', constant_values=0)
                lbl = np.pad(lbl, (pad, 0), 'constant', constant_values=0)
            ex_list.append(inp_ex)
            resp_list.append(inp_resp)
            label_list.append(lbl)
    if len(ex_list) == 0:
        return None, None, None
    ex = np.stack(ex_list).astype(np.int64)
    resp = np.stack(resp_list).astype(np.int64)
    label = np.stack(label_list).astype(np.int64)
    return ex, resp, label

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--train', default='data/preprocessed_data_train.csv')
    parser.add_argument('--test', default='data/preprocessed_data_test.csv')
    parser.add_argument('--output', default='experiments/assistments_sakt_splits.npz')
    parser.add_argument('--seq_len', type=int, default=50)
    args = parser.parse_args()

    os.makedirs(os.path.dirname(args.output), exist_ok=True)

    train_df = pd.read_csv(args.train, sep=None, engine='python')
    test_df = pd.read_csv(args.test, sep=None, engine='python')

    all_items = pd.concat([train_df['item_id'], test_df['item_id']]).unique()
    item2i = {it: idx+1 for idx, it in enumerate(all_items)}

    ex_train, resp_train, label_train = build_windows(train_df, item2i, args.seq_len)
    ex_test, resp_test, label_test = build_windows(test_df, item2i, args.seq_len)

    if ex_train is None:
        raise RuntimeError("No train sequences were generated. Try lowering seq_len or min interactions.")
    if ex_test is None:
        print("Warning: no test sequences generated; check test file.")

    np.savez_compressed(args.output,
                        ex_train=ex_train, resp_train=resp_train, label_train=label_train,
                        ex_test=ex_test, resp_test=resp_test, label_test=label_test,
                        n_items=len(item2i)+1)
    print("Saved:", args.output)
    print("Shapes (train):", ex_train.shape, resp_train.shape, label_train.shape)
    if ex_test is not None:
        print("Shapes (test):", ex_test.shape, resp_test.shape, label_test.shape)
    print("n_items (including padding idx 0):", len(item2i)+1)

if __name__ == '__main__':
    main()
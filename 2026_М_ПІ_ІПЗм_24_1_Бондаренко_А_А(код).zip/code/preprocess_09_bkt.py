import pandas as pd
import numpy as np
import os

df = pd.read_csv(
    "data/skill_builder_data_corrected_collapsed.csv",
    encoding="latin1",
    low_memory=False
)

print("Raw data:", df.shape)
print("\nColumns in dataset:")
print(df.columns.tolist())

rename_map = {
    "user_id": "user_id",
    "user": "user_id",
    "student_id": "user_id",

    "skill_id": "skill_id",

    "correct": "correct",
    "outcome": "correct",

    "order_id": "timestamp",
}

existing_map = {k: v for k, v in rename_map.items() if k in df.columns}
df = df.rename(columns=existing_map)

df = df.loc[:, ~df.columns.duplicated()]

required_cols = ["user_id", "skill_id", "correct"]

missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"Required column(s) missing: {missing}")

if "timestamp" not in df.columns:
    if "ms_first_response" in df.columns:
        df["timestamp"] = df["ms_first_response"]
        print("Using ms_first_response as timestamp")
    else:
        raise ValueError("No valid timestamp column found")

df = df[["user_id", "skill_id", "correct", "timestamp"]].copy()

df = df.dropna(subset=["user_id", "skill_id", "correct", "timestamp"])

df["correct"] = df["correct"].astype(int)
df["timestamp"] = pd.to_numeric(df["timestamp"], errors="coerce")

df = df.dropna(subset=["timestamp"])

df = df.sort_values(["user_id", "timestamp"]).reset_index(drop=True)

user_counts = df.groupby("user_id").size()
valid_users = user_counts[user_counts >= 20].index
df = df[df["user_id"].isin(valid_users)].reset_index(drop=True)
print(f"Users with >=20 interactions: {df['user_id'].nunique()}")

skill_counts = df.groupby("skill_id").size()
valid_skills = skill_counts[skill_counts >= 50].index
df = df[df["skill_id"].isin(valid_skills)].reset_index(drop=True)
print(f"Skills with >=50 interactions: {df['skill_id'].nunique()}")

def split_by_time_per_user(user_data, train_ratio=0.8):
    time_split = user_data["timestamp"].quantile(train_ratio)
    train_mask = user_data["timestamp"] <= time_split
    return user_data[train_mask], user_data[~train_mask]

train_list = []
test_list = []

for user in df["user_id"].unique():
    user_data = df[df["user_id"] == user].reset_index(drop=True)
    if len(user_data) >= 10:
        train_user, test_user = split_by_time_per_user(user_data, train_ratio=0.8)
        if len(test_user) > 0:
            train_list.append(train_user)
            test_list.append(test_user)

train = pd.concat(train_list, ignore_index=True)
test = pd.concat(test_list, ignore_index=True)

print(f"\nTrain: {train.shape}, timestamp: {train['timestamp'].min():.0f}-{train['timestamp'].max():.0f}")
print(f"Test:  {test.shape}, timestamp: {test['timestamp'].min():.0f}-{test['timestamp'].max():.0f}")
print(f"Train users: {train['user_id'].nunique()}, Test users: {test['user_id'].nunique()}")
print(f"Shared users: {len(set(train['user_id']) & set(test['user_id']))}")
print(f"Train correct rate: {train['correct'].mean():.4f}")
print(f"Test correct rate: {test['correct'].mean():.4f}")

common_skills = set(train["skill_id"].unique()) & set(test["skill_id"].unique())
train = train[train["skill_id"].isin(common_skills)].reset_index(drop=True)
test = test[test["skill_id"].isin(common_skills)].reset_index(drop=True)
print(f"Common skills: {len(common_skills)}")

train = train.rename(columns={
    "user_id": "user",
    "skill_id": "skill"
})

test = test.rename(columns={
    "user_id": "user",
    "skill_id": "skill"
})
os.makedirs("data", exist_ok=True)
train.to_csv("data/09_train.csv", index=False)
test.to_csv("data/09_test.csv", index=False)
print("Saved train/test CSV for Skill Builder dataset")

print("\nFinal dataset preview:")
print(train.head())
import random
import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import roc_auc_score
import argparse
import os
from model import sakt
from sklearn.metrics import roc_auc_score, accuracy_score, f1_score


class SeqDataset(Dataset):
    def __init__(self, ex, resp, label):
        self.ex = ex
        self.resp = resp
        self.label = label
    def __len__(self):
        return self.ex.shape[0]
    def __getitem__(self, idx):
        return self.ex[idx], self.resp[idx], self.label[idx]

def collate_fn(batch):
    ex, resp, lbl = zip(*batch)
    return (torch.tensor(np.stack(ex), dtype=torch.long),
            torch.tensor(np.stack(resp), dtype=torch.long),
            torch.tensor(np.stack(lbl), dtype=torch.float))

def eval_metrics(model, loader, device, n_items):
    model.eval()
    all_preds, all_labels = [], []

    with torch.no_grad():
        for ex, resp, lbl in loader:
            ex = ex.to(device)
            resp = resp.to(device)

            interaction = ex + resp * n_items
            out = model(interaction, ex)

            preds = out.cpu().numpy().ravel()
            labels = lbl.cpu().numpy().ravel()

            all_preds.append(preds)
            all_labels.append(labels)

    all_preds = np.concatenate(all_preds)
    all_labels = np.concatenate(all_labels)

    try:
        auc = roc_auc_score(all_labels, all_preds)
    except:
        auc = float('nan')

    binary_preds = (all_preds >= 0.5).astype(int)

    accuracy = accuracy_score(all_labels, binary_preds)
    f1 = f1_score(all_labels, binary_preds)

    return auc, accuracy, f1

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, default="experiments/assistments_sakt_splits.npz")
    parser.add_argument("--seq_len", type=int, default=50)
    parser.add_argument("--batch", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--lr", type=float, default=1e-3)
    args = parser.parse_args()

    arr = np.load(args.data)
    
    ex_train = arr['ex_train']; resp_train = arr['resp_train']; label_train = arr['label_train']
    ex_test = arr['ex_test']; resp_test = arr['resp_test']; label_test = arr['label_test']
    n_items = int(arr['n_items'])

    train_ds = SeqDataset(ex_train, resp_train, label_train)
    test_ds = SeqDataset(ex_test, resp_test, label_test)
    train_loader = DataLoader(train_ds, batch_size=args.batch, shuffle=True, collate_fn=collate_fn)
    test_loader = DataLoader(test_ds, batch_size=args.batch, shuffle=False, collate_fn=collate_fn)

    device = torch.device("cpu")
    print("Device:", device)

    auc_scores = []
    acc_scores = []
    f1_scores = []
    
    NUM_RUNS = 5

    for run in range(NUM_RUNS):

        print(f"\n===== RUN {run+1}/{NUM_RUNS} =====")

        seed = run

        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)

        model = sakt(
            ex_total=n_items,
            seq_len=args.seq_len - 1,
            dim=128,
            heads=4,
            dout=0.2
        ).to(device)

        opt = torch.optim.Adam(model.parameters(), lr=args.lr)

        loss_fn = nn.BCELoss()

        best_auc = 0.0

        for epoch in range(1, args.epochs + 1):

            model.train()
            total_loss = 0.0

            for ex, resp, lbl in train_loader:

                ex = ex.to(device)
                resp = resp.to(device)
                lbl = lbl.to(device)

                opt.zero_grad()

                interaction = ex + resp * n_items
                out = model(interaction, ex)

                out = out.view(-1)
                lbl = lbl.view(-1)

                loss = loss_fn(out, lbl)

                loss.backward()
                opt.step()

                total_loss += loss.item()

            train_loss = total_loss / len(train_loader)

            auc, acc, f1 = eval_metrics(
                model,
                test_loader,
                device,
                n_items
            )

            if auc > best_auc:
                best_auc = auc

            print(
                f"Epoch {epoch}: "
                f"AUC {auc:.4f}  "
                f"ACC {acc:.4f}  "
                f"F1 {f1:.4f}"
            )

        auc_scores.append(auc)
        acc_scores.append(acc)
        f1_scores.append(f1)


    print("\n===== FINAL RESULTS =====")

    print(
        f"AUC: {np.mean(auc_scores):.4f} ± {np.std(auc_scores):.4f}"
    )

    print(
        f"Accuracy: {np.mean(acc_scores):.4f} ± {np.std(acc_scores):.4f}"
    )

    print(
        f"F1-score: {np.mean(f1_scores):.4f} ± {np.std(f1_scores):.4f}"
    )

if __name__ == '__main__':
    main()
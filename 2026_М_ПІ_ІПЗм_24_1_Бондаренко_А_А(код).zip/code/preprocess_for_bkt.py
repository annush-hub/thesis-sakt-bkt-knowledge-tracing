import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split
import os

df = pd.read_csv("data/assistments17.csv", dtype={'Ln-1': str, 'Ln': str}, low_memory=False)
print("Raw data:", df.shape)

df = df.rename(columns={
    "studentId":  "user",
    "skill":      "skill",
    "correct":    "correct",
    "action_num": "timestamp"
})

df = df[["user", "skill", "correct", "timestamp"]].dropna()
df["correct"] = df["correct"].astype(int)

df = df.sort_values(["user", "timestamp"]).reset_index(drop=True)

user_counts = df.groupby("user").size()
valid_users = user_counts[user_counts >= 30].index
df = df[df["user"].isin(valid_users)].reset_index(drop=True)
print(f"Користувачів з ≥30 спроб: {df['user'].nunique()}")

skill_counts = df.groupby("skill").size()
valid_skills = skill_counts[skill_counts >= 100].index
df = df[df["skill"].isin(valid_skills)].reset_index(drop=True)
print(f"Навичок з ≥100 спроб: {df['skill'].nunique()}")

def split_by_time_per_user(user_data, train_ratio=0.8):
    time_split = user_data["timestamp"].quantile(train_ratio)
    train_mask = user_data["timestamp"] <= time_split
    return user_data[train_mask], user_data[~train_mask]

train_list = []
test_list = []

for user in df["user"].unique():
    user_data = df[df["user"] == user].reset_index(drop=True)
    if len(user_data) >= 10:  
        user_train, user_test = split_by_time_per_user(user_data, train_ratio=0.8)
        if len(user_test) > 0: 
            train_list.append(user_train)
            test_list.append(user_test)

train = pd.concat(train_list, ignore_index=True)
test = pd.concat(test_list, ignore_index=True)

print(f"\nTrain: {train.shape}, timestamp: {train['timestamp'].min():.0f}-{train['timestamp'].max():.0f}")
print(f"Test:  {test.shape},  timestamp: {test['timestamp'].min():.0f}-{test['timestamp'].max():.0f}")
print(f"Train users: {train['user'].nunique()}, Test users: {test['user'].nunique()}")
print(f"Спільні користувачі: {len(set(train['user']) & set(test['user']))}")
print(f"Train correct rate: {train['correct'].mean():.4f}")
print(f"Test correct rate:  {test['correct'].mean():.4f}")

common_skills = set(train["skill"].unique()) & set(test["skill"].unique())
train = train[train["skill"].isin(common_skills)]
test  = test[test["skill"].isin(common_skills)]
print(f"Спільні навички: {len(common_skills)}")

os.makedirs("data", exist_ok=True)
train.to_csv("data/train_bkt.csv", index=False)
test.to_csv("data/test_bkt.csv",   index=False)
print("Saved train/test CSV")
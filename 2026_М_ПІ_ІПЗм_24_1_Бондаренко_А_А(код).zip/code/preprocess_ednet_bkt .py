import pandas as pd
import numpy as np
import glob
import os

DATA_PATH = "data/kt1/*.parquet"

N_USERS = 10000      
MIN_USER_INTERACTIONS = 20
MIN_SKILL_INTERACTIONS = 50

np.random.seed(42)

files = sorted(glob.glob(DATA_PATH))

print("Found files:", len(files))


print("\nReading first file to sample users...")

first_df = pd.read_parquet(files[0])

unique_users = first_df["subject_id"].unique()

sample_size = min(N_USERS, len(unique_users))

sampled_users = np.random.choice(
    unique_users,
    size=sample_size,
    replace=False
)

print("Sampled users:", len(sampled_users))

del first_df


dfs = []

for i, f in enumerate(files):

    print(f"\nProcessing file {i+1}/{len(files)}")

    df_part = pd.read_parquet(
        f,
        columns=[
            "timestamp",
            "subject_id",
            "question_id",
            "is_correct",
            "elapsed_time"
        ]
    )


    df_part = df_part[
        df_part["subject_id"].isin(sampled_users)
    ]

    dfs.append(df_part)

df = pd.concat(dfs, ignore_index=True)

print("\nAfter sampling:", df.shape)

del dfs

df["user_id"] = df["subject_id"]
df["skill"] = df["question_id"]
df["correct"] = df["is_correct"]

df["correct"] = df["correct"].astype(int)

print("\nColumns:", df.columns)
print("\nFiltering users...")

user_counts = df["user_id"].value_counts()

valid_users = user_counts[
    user_counts >= MIN_USER_INTERACTIONS
].index

df = df[df["user_id"].isin(valid_users)]

print("After user filter:", df.shape)
print("\nFiltering skills...")

skill_counts = df["skill"].value_counts()
top_skills = df["skill"].value_counts().head(100).index
df = df[df["skill"].isin(top_skills)]

valid_skills = skill_counts[
    skill_counts >= MIN_SKILL_INTERACTIONS
].index

df = df[df["skill"].isin(valid_skills)]

print("After skill filter:", df.shape)
print("\nSorting...")

df = df.sort_values(
    ["user_id", "timestamp"]
)


print("\nCreating train/test split...")

train_list = []
test_list = []

for user, user_df in df.groupby("user_id"):

    split_idx = int(len(user_df) * 0.8)

    train_list.append(
        user_df.iloc[:split_idx]
    )

    test_list.append(
        user_df.iloc[split_idx:]
    )

train_df = pd.concat(train_list)
test_df = pd.concat(test_list)

print("\nTrain shape:", train_df.shape)
print("Test shape:", test_df.shape)


print("\nSaving files...")

train_df.to_csv(
    "ednet_bkt_train.csv",
    index=False
)

test_df.to_csv(
    "ednet_bkt_test.csv",
    index=False
)

print("\nDone! Files saved:")
print("ednet_bkt_train.csv")
print("ednet_bkt_test.csv")